<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interventor</title>

    <link rel="stylesheet" href="./styles/styles.css">
</head>
<body>

<?php

require '../../../main.inc.php';
?>

    <div class="main">
        <?php echo '<a href="'. DOL_URL_ROOT .'/custom/observaciones/interventor/interventor_index.php">'?>
            <div class="logo">
                <img src="./img/ultimate.png" alt="ultimate">
            </div>
        </a>
CREATE TABLE `llx_c_aiu_administracion`
(
  `rowid` int(11) NOT NULL auto_increment,  
  `valor` int(2),  
  `active` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=innodb;
insert into llx_c_aiu_administracion (rowid,valor) VALUES (1,0);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (2,1);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (3,2);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (4,3);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (5,4);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (6,5);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (7,6);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (8,7);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (9,8);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (10,9);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (11,10);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (12,11);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (13,12);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (14,13);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (15,14);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (16,15);
insert into llx_c_aiu_administracion (rowid,valor) VALUES (17,16);

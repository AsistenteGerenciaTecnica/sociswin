<?php
//session_start();

//Conexion a la Base de Datos
$conn = mysqli_connect(
  'localhost',
  'dolibarr',//usuario
  'Mi-Password',//contraseña
  'dolibarr'//base de datos
) or die(mysqli_erro($mysqli));


?>

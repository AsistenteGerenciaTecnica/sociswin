INSERT INTO llx_extrafields (name, entity, elementtype, label, type, fieldunique, fieldrequired, enabled, pos, alwayseditable, list, printable, totalizable)
VALUES ('orden_evaluada', '1', 'commande_fournisseur', 'Evaluada', 'boolean', '0', '0', '1', '100', '0', '1', '0', '0');

INSERT INTO llx_extrafields (name, entity, elementtype, label, type, size, fieldunique, fieldrequired, enabled, pos, alwayseditable, list, printable, totalizable)
VALUES ('orden_calificacion', '1', 'commande_fournisseur', 'Calificación', 'varchar', '20', '0', '0', '1', '100', '0', '2', '0', '0');

INSERT INTO llx_extrafields (name, entity, elementtype, label, type, size, fieldunique, fieldrequired, enabled, pos, alwayseditable, list, printable, totalizable)
VALUES ('tercero_evaluacion', '1', 'societe', 'Calificación', 'varchar', '20', '0', '0', '1', '100', '0', '2', '0', '0');